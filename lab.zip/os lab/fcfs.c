#include<stdio.h>
#include<math.h>

struct process{
	int at,bt,ct,tat,wt,done;  // 1-completed, 0-not completed
}processes[10];

int dispatcher(int time, int n){
	int min=99999;
	int ind = -1;
	for(int i=0; i<n; i++){
		if((processes[i].done==0) && (processes[i].at<=time) && (processes[i].at<min)){
			min = processes[i].at;
			ind = i;
		}
	}
	return ind;
}

int n;

int main(){
	printf("Enter no. of processes: ");
	scanf("%d", &n);
	for(int i=0; i<n; i++){
		printf("Process %d\n", i+1);
		printf("Enter Arrival time: ");
		scanf("%d", &processes[i].at);
		printf("Enter Burst time: ");
		scanf("%d", &processes[i].bt);
		processes[i].done=0;
	}
	int i=0,curr_time = 0,pid;
	while(i<n){
		pid = dispatcher(curr_time, n);
		processes[pid].ct = curr_time+processes[pid].bt;
		processes[pid].tat = processes[pid].ct - processes[pid].at;
		processes[pid].wt = processes[pid].tat - processes[pid].bt;
		processes[pid].done = 1;
		curr_time += processes[pid].bt;
		i++;
	}
	printf("Process\t Arrival Time\t Burst Time\t Completion Time\t TA Time\t Waiting Time\n");
	for(i=0; i<n;i++){
		printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n", i, processes[i].at, processes[i].bt, processes[i].ct, processes[i].tat, processes[i].wt);
	}
	float mean_tat = 0,mean_wt = 0;
	for(int i=0; i<n; i++){
		mean_tat+=processes[i].tat;
		mean_wt+=processes[i].wt;
	}
	mean_tat/=n;
	mean_wt/=n;
	printf("Mean TA Time: %f\n", mean_tat);
	printf("Mean Waiting Time: %f\n", mean_wt); 
}

/*
Enter no. of processes: 5
Process 1
Enter Arrival time: 1
Enter Burst time: 4
Process 2
Enter Arrival time: 0
Enter Burst time: 6
Process 3
Enter Arrival time: 2
Enter Burst time: 2
Process 4
Enter Arrival time: 4
Enter Burst time: 5
Process 5
Enter Arrival time: 3
Enter Burst time: 7
Process	 Arrival Time	 Burst Time	 Completion Time	 TA Time	 Waiting Time
0		1		4		10		9		5
1		0		6		6		6		0
2		2		2		12		10		8
3		4		5		24		20		15
4		3		7		19		16		9
Mean TA Time: 12.200000
Mean Waiting Time: 7.400000
*/

