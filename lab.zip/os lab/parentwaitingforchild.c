#include <stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>
int main(){
	int pid,status,childPid;
	printf("I’m the parent process and my PID is %d\n", getpid());
	pid=fork();
	if(pid>0){
		printf("I’m the parent process with PID %d and PPID %d.\n", getpid(),getppid());
		childPid = wait( &status ); /* Wait for a child to terminate. */
		printf("A child with PID %d terminated with exit code %d \n",childPid,status>> 8);
	}
	else{
		printf("I’m the child process with PID %d and PPID %d.\n",getpid(),getppid());
		exit(42); /* Exit with a silly number */
	}
	printf("PID %d terminates.\n",getpid());
}

/*I’m the parent process and my PID is 3942
I’m the parent process with PID 3942 and PPID 3596.
I’m the child process with PID 3943 and PPID 3942.
A child with PID 3943 terminated with exit code 42 
PID 3942 terminates.*/
