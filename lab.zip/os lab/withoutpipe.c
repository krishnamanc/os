#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int main(){
	pid_t pid;
	printf("I’m the original process with PID %d and PPID %d.\n", getpid(),getppid());
	pid=fork();
	if ( pid> 0 ){ /* pid>0 for parent */
		printf("I’m the parent process with PID %d and PPID %d.\n",getpid(),getppid());
		printf("My child’s PID is %d \n", pid );
	}
	else{/* pid=0 for child */
		printf("I’m the child process with PID %d and PPID %d.\n",getpid(),getppid());
	}
}

/*I’m the original process with PID 3644 and PPID 3596.
I’m the parent process with PID 3644 and PPID 3596.
My child’s PID is 3645 
I’m the child process with PID 3645 and PPID 3644.*/
