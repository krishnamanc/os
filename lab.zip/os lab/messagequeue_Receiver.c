#include<stdio.h> //create msgqueuefile where program is saved using touch msgqueuefile
#include<stdlib.h>
#include<errno.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
struct msgbuf{
	long mtype;
	char mtext[100];
};
int main(){
	int mgID;
	key_t key;
	struct msgbuf buf;
	key = ftok("msgqueuefile", 65);
	if((mgID = msgget(key,0666)) == -1){
		perror("msgget");
		exit(1);
	}
	printf("Message queue created...");
	while(1){
		printf("\n\nWaiting for Message  from sender...");
		if(msgrcv(mgID,&buf,sizeof(buf.mtext),0,0) == -1){
			perror("msgrcv");
			exit(1);
		}
		printf("\nMessage received: %s",buf.mtext);
		if(strcmp(buf.mtext,"bye") == 0)
			break;
	}
	msgctl(mgID,IPC_RMID,NULL);
	printf("\n\nExited..\n\n");
}
