#include <stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>
int main(){
	pid_t pid;
	pid=fork();
	if(pid>0){/*pid >0 for parent*/
		while(1) /* Never terminate, and never execute a wait() */
			sleep(10);
	}
	else{
		exit(15);
	}
}
