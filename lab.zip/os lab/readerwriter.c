#include <pthread.h>
#include <sched.h>
#include <semaphore.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#define MAXTHREAD 5  /* define # readers */
#define MAX_READS 5  /* define how many times each reader reads */
#define MAX_WRITES 5 /* define how many times the writer writes */

int SharedData;

void* reader(void* arg);
void* writer(void* arg);

sem_t rLock, wLock;  /* establish semaphores */
int rc = 0;  /* number of processes reading */

int main()
{
    pthread_t rId[MAXTHREAD], wId;
    int i, ids[MAXTHREAD];

    sem_init(&rLock, 0, 1);  /* initialize semaphores */
    sem_init(&wLock, 0, 1);

    /* Create reader threads */
    for (i = 0; i < MAXTHREAD; i++) {
        ids[i] = i + 1;
        if (pthread_create(&rId[i], NULL, reader, &ids[i]) != 0) {
            perror("Cannot create reader!");
            exit(1);
        }
    }

    /* Create writer thread */
    if (pthread_create(&wId, NULL, writer, NULL) != 0) {
        perror("Cannot create writer");
        exit(1);
    }

    /* Wait for writer and readers to finish */
    pthread_join(wId, NULL);
    for (i = 0; i < MAXTHREAD; i++) {
        pthread_join(rId[i], NULL);
    }

    /* Clean up */
    sem_destroy(&rLock);
    sem_destroy(&wLock);

    return 0;
}

void* reader(void* arg)  /* reader function */
{
    int id = *(int*)arg;
    int read_count = 0;

    while (read_count < MAX_READS)  /* finite number of reads */
    {
        sleep(1);  /* simulate reading delay */
        sem_wait(&rLock);
        rc++;
        if (rc == 1)  /* first reader locks writer */
            sem_wait(&wLock);
        sem_post(&rLock);

        printf("\nReader %d Read Value: %d...", id, SharedData);
        read_count++;  /* increase local read count */

        sem_wait(&rLock);
        rc--;
        if (rc == 0)  /* last reader unlocks writer */
            sem_post(&wLock);
        sem_post(&rLock);
    }

    return NULL;
}

int getNext()  /* writer's function to generate next data */
{
    static int data = 100;
    return data++;
}

void* writer(void* arg)  /* writer function */
{
    int write_count = 0;

    while (write_count < MAX_WRITES)  /* finite number of writes */
    {
        sleep(1);  /* simulate writing delay */
        sem_wait(&wLock);

        printf("\nWriter is now writing... Number of readers: %d\n", rc);
        SharedData = getNext();
        write_count++;  /* increase write count */

        sem_post(&wLock);
    }

    return NULL;
}
