#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main(){
	int p[2],pid;
	char inbuf[50],outbuf[50];
	if(pipe(p)==-1){// Error in Pipe creation
		printf("pipe failed\n");
        return 0;
    }
	pid=fork();
	if(pid>0){ //Parent process
		printf("In parent process.\nType the data to be sent to child:");
		scanf("%s",outbuf);
		write (p[1],outbuf, sizeof(outbuf));// Write data to child
        wait(NULL);
        printf("in parent process. Child received data.\n");
		
	}else if(pid==0){//child process
		read(p[0],inbuf,sizeof(inbuf));
		printf("In child process.\nThe data received is %s\n",inbuf);
	}else{
			printf("Unable to create child.\n");
	}
}