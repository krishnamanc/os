#include <stdio.h>
#include<unistd.h>
#include<sys/types.h>
int main(){
	int pid;
	printf("I’m the original process with PID %d and PPID %d.\n",getpid(),getppid());
	pid=fork();
	if (pid>0){/* pid>0 for parent */
		printf("I’m the parent process with PID %d and PPID %d.\n",getpid(),getppid());
		printf("My child’s PID is %d.\n", pid );
	}
	else{/* pid=0 for child */
		sleep(5); /* Make sure that the parent terminates first */
		printf("I’m the child process with PID %d and PPID %d.\n",getpid(),getppid());
	}
	printf("PID %d terminates.\n",getpid());/* Both processes execute this */
}
/*I’m the original process with PID 3721 and PPID 3596.
I’m the parent process with PID 3721 and PPID 3596.
My child’s PID is 3722.
PID 3721 terminates.

I’m the child process with PID 3722 and PPID 1593.
PID 3722 terminates.*/
