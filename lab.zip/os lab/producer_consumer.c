#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>  // For sleep function

// Define the buffer size
#define BUFFER_SIZE 10

// Declare the buffer and related variables
int buffer[BUFFER_SIZE];
int in = 0;
int out = 0;
int count = 0;

// Declare semaphores (basic integer semaphores)
int mutex = 1;      // Semaphore for mutual exclusion
int empty = BUFFER_SIZE; // Semaphore to track empty slots
int full = 0;       // Semaphore to track full slots

// Function to implement wait (decrement semaphore)
void wait(int *semaphore) {
    while (*semaphore <= 0); // Busy wait
    (*semaphore)--;
}

// Function to implement signal (increment semaphore)
void sem_signal(int *semaphore) {
    (*semaphore)++;
}

// Producer function
void produce_item() {
    if (count == BUFFER_SIZE) {
        printf("Buffer is full. Cannot produce item.\n");
        return;
    }

    int item = rand() % 100;  // Produce a random item

    wait(&empty); // Wait if the buffer is full
    wait(&mutex); // Enter critical section

    // Add the item to the buffer
    buffer[in] = item;
    printf("Producer produced item %d at index %d\n", item, in);
    in = (in + 1) % BUFFER_SIZE;
    count++;

    sem_signal(&mutex); // Exit critical section
    sem_signal(&full);  // Signal that buffer is not empty
}

// Consumer function
void consume_item() {
    if (count == 0) {
        printf("Buffer is empty. Cannot consume item.\n");
        return;
    }

    wait(&full);  // Wait if the buffer is empty
    wait(&mutex); // Enter critical section

    // Remove the item from the buffer
    int item = buffer[out];
    printf("Consumer consumed item %d from index %d\n", item, out);
    out = (out + 1) % BUFFER_SIZE;
    count--;

    sem_signal(&mutex); // Exit critical section
    sem_signal(&empty); // Signal that buffer is not full
}

// Menu function
void menu() {
    int choice;
    do {
        printf("\nMenu:\n");
        printf("1. Produce an item\n");
        printf("2. Consume an item\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                produce_item();
                break;
            case 2:
                consume_item();
                break;
            case 3:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }

        // Simulate delay for thread execution
        sleep(1);

    } while (choice != 3);
}

int main() {
    // Initialize random number generator
    srand(time(NULL));

    // Start the menu-driven program
    menu();

    return 0;
}