#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(){
	int p[2],pid1,pid2;
	char inbuf[50],outbuf[50];
	if(pipe(p)==-1){
		printf("unable to create pipe\n");
	}
	pid1=fork();//Child1
	if(pid1>0){//Parent process
		printf("in parent process.\n");
		wait(NULL); 
		pid2 = fork();//Child2
		if (pid2>0){//Parent
			wait(NULL);
		}else if(pid2==0){//Child 2
			printf("in child 2 process\n");
			read(p[0],inbuf,50);
			printf("the data received here is %s\n",inbuf);
		}else{
			printf("unable to create child2\n");
		}
	}else if(pid1==0){//Child 1
		printf("in child 1 process\nwriting to child 2:\n");
		scanf("%s",outbuf);
		write(p[1],outbuf,sizeof(outbuf));
		
	}else{
		printf("unable to create child1\n");
	}
}
