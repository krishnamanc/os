#include<stdio.h>
#include<math.h>

struct process{
	int at,bt1,io,bt2,ct,tat,wt,bt1done,cbt,done;  // 1-completed, 0-not completed
}p[10];

int dispatcher(int time, int n){
	int min = 99999;
	int ind = -1;
	for(int i = 0;i < n;i++){
		if(p[i].done==0){
			if ((p[i].cbt <= time) && (p[i].cbt < min)){
				min = p[i].cbt;
				ind = i;
			}
			else if((p[i].cbt > time) && (p[i].cbt < min)){
				min = p[i].cbt;
				ind = i;
			}
		}
	}
	return ind;
}

int n;

int main(){
	printf("Enter no. of processes: ");
	scanf("%d", &n);
	for(int i=0; i<n; i++){
		printf("Process %d\n", i+1);
		printf("Enter Arrival time: ");
		scanf("%d", &p[i].at);
		printf("Enter Burst time 1: ");
		scanf("%d", &p[i].bt1);
		printf("Enter IO time: ");
		scanf("%d", &p[i].io);
		printf("Enter Burst time 2: ");
		scanf("%d", &p[i].bt2);
		p[i].cbt=p[i].at;
		p[i].bt1done=0;
		p[i].done=0;
	}
	int i = 0,curr_time = 0,pid;
	while(i < n){
		pid = dispatcher(curr_time, n);
		if (pid != -1){
			if (p[pid].cbt > curr_time) {
                curr_time = p[pid].cbt;
            }
			if(p[pid].bt1done == 0){
				curr_time += p[pid].bt1;
				p[pid].bt1done = 1;
				p[pid].cbt = curr_time + p[pid].io;
			}
			else{
				p[pid].done = 1;
				curr_time += p[pid].bt2;
				p[pid].ct = curr_time;
				p[pid].tat = p[pid].ct - p[pid].at;
				p[pid].wt = p[pid].tat - (p[pid].bt1 + p[pid].bt2);
				i++;
			}
		}
		else{
			curr_time+=1;
		}
	}
	printf("Process\t ArrivalTime\t BurstTime1\t IOTime\t BurstTime2\t CompletionTime\t TATime\t WaitingTime\n");
	for(i=0; i<n;i++){
		printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",i+1,p[i].at,p[i].bt1,p[i].io,p[i].bt2,p[i].ct,p[i].tat,p[i].wt);
	}
	float mean_tat = 0,mean_wt = 0;
	for(int i=0; i<n; i++){
		mean_tat+=p[i].tat;
		mean_wt+=p[i].wt;
	}
	mean_tat/=n;
	mean_wt/=n;
	printf("Mean TA Time: %f\n", mean_tat);
	printf("Mean Waiting Time: %f\n", mean_wt); 
}

/*Enter no. of processes: 3
Process 1
Enter Arrival time: 2
Enter Burst time 1: 9
Enter IO time: 15
Enter Burst time 2: 6
Process 2
Enter Arrival time: 3
Enter Burst time 1: 3
Enter IO time: 5
Enter Burst time 2: 2
Process 3
Enter Arrival time: 1
Enter Burst time 1: 6
Enter IO time: 10
Enter Burst time 2: 4
Process  ArrivalTime     BurstTime1      IOTime  BurstTime2      CompletionTime  TATime  WaitingTime
1               2               9               15              6               37              35              20
2               3               3               5               2               26              23              18
3               1               6               10              4               23              22              12
Mean TA Time: 26.666666
Mean Waiting Time: 16.666666*/