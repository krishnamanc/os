#include<stdio.h>
int main(){
    int i,j,np,nr,ind=0;
    printf("Enter no. of processes:");
   	scanf("%d",&np);
    printf("Enter no. of resources:");
   	scanf("%d",&nr);
    int alloc[np][nr],request[np][nr],avail[nr],f[np],ans[np];
    for(i=0;i<np;i++){
        f[i]=0;
    }
    for(i=0;i<nr;i++){
        printf("Enter no. of instances of R%d: ",i+1);
        scanf("%d",&avail[i]);
    }
    for(i=0;i<np;i++){
        for(j=0;j<nr;j++){
            printf("Enter no. of instances of R%d allocated to P%d: ",j+1,i+1);
            scanf("%d",&alloc[i][j]);
            avail[j]-=alloc[i][j];
        }
    }
    for(i=0;i<np;i++){
        for(j=0;j<nr;j++){
            printf("Enter no. of instances of R%d requested by P%d: ",j+1,i+1);
            scanf("%d",&request[i][j]);
        }
    }
    for(int k=0;k<np;k++){
        for(i=0;i<np;i++){
            if(f[i]==0){
			    int flag = 0;
                for(j=0;j<nr;j++){
                    if(request[i][j] > avail[j]){
                        flag = 1;
         			    break;
                    }
                }
                if(flag == 0){
                    ans[ind++] = i+1;
                    for(int y=0;y<nr;y++){
        			    avail[y] += alloc[i][y];
				    }
                    f[i] = 1;
                }
		    }
        }
    }

    int deadlock=0;
    for(i=0;i<np;i++){
  		if(f[i]==0){ 
    		deadlock=1;
     		printf("Deadlock detected\n");
    		break;
  		}
	}
  	if(deadlock==0){
  		printf("Following is the SAFE Sequence\n");
  		for(i=0;i<np-1;i++){
    		printf("P-%d->",ans[i]);
	    }
     	printf("P-%d",ans[np-1]);
    }
}
/*Enter no. of processes:4
Enter no. of resources:3
Enter no. of instances of R1: 2
Enter no. of instances of R2: 3
Enter no. of instances of R3: 2
Enter no. of instances of R1 allocated to P1: 1
Enter no. of instances of R2 allocated to P1: 0
Enter no. of instances of R3 allocated to P1: 1
Enter no. of instances of R1 allocated to P2: 1
Enter no. of instances of R2 allocated to P2: 1
Enter no. of instances of R3 allocated to P2: 0
Enter no. of instances of R1 allocated to P3: 0
Enter no. of instances of R2 allocated to P3: 1
Enter no. of instances of R3 allocated to P3: 0
Enter no. of instances of R1 allocated to P4: 0
Enter no. of instances of R2 allocated to P4: 1
Enter no. of instances of R3 allocated to P4: 0
Enter no. of instances of R1 requested by P1: 0
Enter no. of instances of R2 requested by P1: 0
Enter no. of instances of R3 requested by P1: 1
Enter no. of instances of R1 requested by P2: 1
Enter no. of instances of R2 requested by P2: 0
Enter no. of instances of R3 requested by P2: 0
Enter no. of instances of R1 requested by P3: 0
Enter no. of instances of R2 requested by P3: 0
Enter no. of instances of R3 requested by P3: 1
Enter no. of instances of R1 requested by P4: 0
Enter no. of instances of R2 requested by P4: 2
Enter no. of instances of R3 requested by P4: 0
Following is the SAFE Sequence
P-1->P-2->P-3->P-4*/