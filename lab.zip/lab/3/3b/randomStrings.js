// Generate 10 random strings
let string = generateRandomString(6);

// Function to generate a random alphanumeric string of specified length
function generateRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Set the first random string as the initial display
document.addEventListener("DOMContentLoaded", function(){
    const randomStringElement = document.getElementById("randomString");
    randomStringElement.textContent = string;
});
