// Function to get numbers from the user
function getNumbers() {
    let numbers = [];
    let userInput;
    
    // Prompt the user for numbers, up to 10 times
    for (let i = 0; i < 10; i++) {
        userInput = prompt("Enter a number (click Cancel to finish):");
        
        // If user clicks Cancel or enters an empty value, stop the loop
        if (userInput === null || userInput === "") {
            break;
        }

        // Parse input to a number and add to the array
        let num = parseFloat(userInput);
        if (!isNaN(num)) {
            numbers.push(num);
        } else {
            alert("Invalid number, please try again.");
        }
    }

    // Display the numbers entered
    document.getElementById("numbersEntered").textContent = "Numbers entered: " + numbers.join(", ");
    
    // Sort the numbers in ascending order
    numbers.sort((a, b) => a - b);

    // Display the sorted numbers
    document.getElementById("sortedNumbers").textContent = "Sorted numbers: " + numbers.join(", ");
}
