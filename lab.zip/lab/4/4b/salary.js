// Function to calculate average salary using Sentinel-controlled repetition
function calculateAverageSalarySentinel() {
    let totalSalary = 0;
    let count = 0;
    let salary;
    
    while (true) {
        salary = prompt("Enter employee salary (or type 'done' to finish):");
        
        // Sentinel value to stop input
        if (salary.toLowerCase() === "done") {
            break;
        }

        salary = parseFloat(salary);
        if (!isNaN(salary) && salary >= 0) {
            totalSalary += salary;
            count++;
        } else {
            alert("Invalid salary. Please enter a valid number.");
        }
    }

    // Calculate and display the average salary
    let averageSalary = count > 0 ? totalSalary / count : 0;
    document.getElementById("average").textContent = "Average Salary (Sentinel Controlled): $" + averageSalary.toFixed(2);
}

// Function to calculate average salary using Counter-controlled repetition
function calculateAverageSalaryCounter() {
    let totalSalary = 0;
    let count = 10;  // For at least 10 employees

    for (let i = 0; i < count; i++) {
        let salary = parseFloat(prompt("Enter salary for employee " + (i + 1) + ":"));
        if (!isNaN(salary) && salary >= 0) {
            totalSalary += salary;
        } else {
            alert("Invalid salary. Please enter a valid number.");
            i--;  // Retry the current employee if invalid salary
        }
    }

    // Calculate and display the average salary
    let averageSalary = totalSalary / count;
    document.getElementById("average").textContent = "Average Salary (Counter Controlled): $" + averageSalary.toFixed(2);
}

// Call both functions to display average salary
calculateAverageSalarySentinel();
calculateAverageSalaryCounter();
