function divideAndSumArray(arr) {
    let part1 = 0; // Sum of first part
    let part2 = 0; // Sum of second part
    
    arr.forEach((value, index) => {
      if (index % 2 === 0) {
        part1 += value; // even index goes to part1
      } else {
        part2 += value; // odd index goes to part2
      }
    });
  
    return [part1, part2]; // Return sums as an array of size 2
  }
  
  const A1 = [4, 0, 2, 5, 4, 3, 5, 0, 7, 8];
  console.log(divideAndSumArray(A1));
  