document.addEventListener("DOMContentLoaded", function() {
    // Array of font family names
    const fonts = [
        "Arial",
        "Monospace",
        "Times",
        "Courier",
        "Optima"
    ];

    // Select a random font
    const randomFont = fonts[Math.floor(Math.random() * fonts.length)];
    console.log(fonts.length);
    console.log(randomFont);
    // Apply the random font to the paragraph
    document.getElementById("randomFontParagraph").style.fontFamily = randomFont;
});
