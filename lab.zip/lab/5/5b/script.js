// Function to send data using Ajax POST request
function sendData() {
    // Get input values
    let name = document.getElementById('name').value;
    let number = document.getElementById('number').value;
    
    // Validate inputs
    if (!name || !number) {
        alert("Both fields are required.");
        return;
    }

    // Create an Ajax request
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "processData.jsp", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    // Send the data
    xhr.send("name=" + encodeURIComponent(name) + "&number=" + encodeURIComponent(number));

    // Handle the response
    xhr.onload = function() {
        if (xhr.status === 200) {
            document.getElementById('response').textContent = xhr.responseText;
        }
    };
}
