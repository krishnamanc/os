// Create a 2D array with sample values
let array = [
    [3, 5, 7],
    [1, 8, 4],
    [9, 2, 6]
];

// Function to find max and min in the 2D array
function findMaxMin(array) {
    let max = array[0][0];
    let min = array[0][0];
    
    for (let i = 0; i < array.length; i++) {
        for (let j = 0; j < array[i].length; j++) {
            if (array[i][j] > max) max = array[i][j];
            if (array[i][j] < min) min = array[i][j];
        }
    }
    return { max, min };
}

// Multiply every element by 2
function multiplyArrayByTwo(array) {
    let newArray = array.map(row => row.map(value => value * 2));
    return newArray;
}

// Display the original array
document.getElementById("originalArray").textContent = "Original Array: " + JSON.stringify(array);

// Find max and min
let { max, min } = findMaxMin(array);
document.getElementById("maxMin").textContent = "Max Value: " + max + ", Min Value: " + min;

// Multiply elements by 2 and display the new array
let modifiedArray = multiplyArrayByTwo(array);
document.getElementById("modifiedArray").textContent = "Modified Array (Multiplied by 2): " + JSON.stringify(modifiedArray);
