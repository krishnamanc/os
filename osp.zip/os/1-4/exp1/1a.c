#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 100

int main() {
    // Create a pipe for communication
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    // Create a child process
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) { // Child process
        close(pipefd[1]); // Close the write end of the pipe
        char buffer[BUFFER_SIZE];

        // Read message from the parent
        read(pipefd[0], buffer, sizeof(buffer));
        printf("Child (PID: %d) received message: %s\n", getpid(), buffer);
        close(pipefd[0]); // Close the read end of the pipe
        exit(EXIT_SUCCESS);
    } else { // Parent process
        close(pipefd[0]); // Close the read end of the pipe
        char message[BUFFER_SIZE];

        // Get message from user
        printf("Enter a message to send to the child: ");
        fgets(message, sizeof(message), stdin);

        // Write message to the child
        write(pipefd[1], message, sizeof(message));
        printf("Parent (PID: %d) sent message: %s\n", getpid(), message);
        close(pipefd[1]); // Close the write end of the pipe

        // Wait for child to finish
        wait(NULL);
    }

    return 0;
}
