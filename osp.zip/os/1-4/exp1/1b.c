#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define NUM_CHILDREN 3
#define BUFFER_SIZE 100

int main() {
    int pipefd[NUM_CHILDREN][2]; // Pipes for each child
    pid_t pids[NUM_CHILDREN]; // Array to hold child PIDs

    // Create pipes for each child
    for (int i = 0; i < NUM_CHILDREN; i++) {
        if (pipe(pipefd[i]) == -1) {
            perror("pipe");
            exit(EXIT_FAILURE);
        }
    }

    // Create multiple child processes
    for (int i = 0; i < NUM_CHILDREN; i++) {
        pids[i] = fork();
        if (pids[i] < 0) {
            perror("fork");
            exit(EXIT_FAILURE);
        }

        if (pids[i] == 0) { // Child process
            close(pipefd[i][1]); // Close the write end of the pipe
            char buffer[BUFFER_SIZE];

            // Read message from the parent
            read(pipefd[i][0], buffer, sizeof(buffer));
            printf("Child %d (PID: %d) received message: %s\n", i + 1, getpid(), buffer);
            close(pipefd[i][0]); // Close the read end of the pipe
            exit(EXIT_SUCCESS);
        }
    }

    // Parent process
    for (int i = 0; i < NUM_CHILDREN; i++) {
        close(pipefd[i][0]); // Close the read end of the pipe

        // Get message from user
        char message[BUFFER_SIZE];
        printf("Enter a message to send to Child %d: ", i + 1);
        fgets(message, sizeof(message), stdin);

        // Send message to each child
        write(pipefd[i][1], message, sizeof(message));
        close(pipefd[i][1]); // Close the write end after sending
    }

    // Wait for all children to finish
    for (int i = 0; i < NUM_CHILDREN; i++) {
        wait(NULL);
    }

    return 0;
}
