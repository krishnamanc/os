#include <stdio.h>
#include <limits.h>

struct process {
    int at;     // Arrival Time
    int st;     // Service Time (Burst Time)
    int status; // Status (0 = not completed, 1 = completed)
    int ft;     // Finish Time
} ready_list[10];

int n;

int dispatcher(int time) {
    int i, min_bt = INT_MAX, index = -1;
    for (i = 0; i < n; i++) {
        if (ready_list[i].status == 0 && ready_list[i].at <= time && ready_list[i].st <= min_bt) {
            min_bt = ready_list[i].st;
            index = i;
        }
    }
    return index;
}

int main() {
    int i, cur_time = 0, pid;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("Process %d\n***********\n", i + 1);
        printf("Enter Arrival Time: ");
        scanf("%d", &ready_list[i].at);
        printf("Enter Service Time: ");
        scanf("%d", &ready_list[i].st);
        ready_list[i].status = 0;
    }
    i = 0;
    while (i < n) {
        pid = dispatcher(cur_time);
        while (pid == -1) {
            cur_time++;
            pid = dispatcher(cur_time);
        }
        ready_list[pid].ft = cur_time + ready_list[pid].st;
        ready_list[pid].status = 1;
        cur_time += ready_list[pid].st;
        i++;
    }
    printf("\nProcess\t Arrival Time\t Burst Time\t Finish Time\t Turnaround Time\t Waiting Time\n");
    printf("*******\t ************\t **********\t ***********\t **************\t ***********\n");
    for (i = 0; i < n; i++) {
        int tt = ready_list[i].ft - ready_list[i].at;
        int wt = tt - ready_list[i].st;
        printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t\t%d\n", i + 1, ready_list[i].at, ready_list[i].st, ready_list[i].ft, tt, wt);
    }
    return 0;
}
