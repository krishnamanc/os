#include <stdio.h>

struct process {
    int at;  // Arrival Time
    int st;  // Service Time
    int ft;  // Finish Time
    int status; // 0: Not executed, 1: Executed at least once, 2: Completed
} ready[10];

int n, t, com = 0;

int Dispatch(int ct) {
    int index = -1, high_at = 0, high_status = 0;

    for (int i = 0; i < n; i++) {
        if (ready[i].status != 2 && ready[i].at <= ct) {
            if (ready[i].at > high_at) {
                high_at = ready[i].at;
                index = i;
                high_status = ready[i].status; // Reset status when a new high_at is found
            } else if (ready[i].at == high_at) {
                if (ready[i].status < high_status || (ready[i].status == high_status && index > i)) {
                    index = i;
                    high_status = ready[i].status; // Update status
                }
            }
        }
    }
    return index;
}

int main() {
    printf("Enter number of processes: ");
    scanf("%d", &n);
    printf("Enter the time slice: ");
    scanf("%d", &t);

    for (int i = 0; i < n; i++) {
        printf("Process %d\n****************\n", i + 1);
        printf("Enter arrival time: ");
        scanf("%d", &ready[i].at);
        printf("Enter service time: ");
        scanf("%d", &ready[i].st);
        ready[i].status = 0; // Not executed yet
    }

    int cur_time = 0;
    while (com < n) {
        int pid = Dispatch(cur_time);
        if (pid == -1) {
            cur_time++; // Increment time if no process is ready
            continue; 
        }

        if (ready[pid].st <= t) {
            cur_time += ready[pid].st; // Complete the process
            ready[pid].ft = cur_time;
            ready[pid].status = 2; // Mark as completed
            com++;
        } else {
            cur_time += t; // Execute for time slice
            ready[pid].st -= t; // Reduce remaining service time
            ready[pid].status = 1; // Mark as executed once
        }
    }

    printf("\nProcess-ID\tArrival Time\tService Time\tFinish Time\tTurnaround Time\tWaiting Time\n");
    printf("***************************************************************************************\n");
    for (int i = 0; i < n; i++) {
        printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n", i + 1, ready[i].at, ready[i].st,
               ready[i].ft, ready[i].ft - ready[i].at, (ready[i].ft - ready[i].at) - (ready[i].st));
    }

    return 0;
}
