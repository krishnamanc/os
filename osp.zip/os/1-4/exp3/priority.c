#include <stdio.h>

struct process {
    int at;  // Arrival Time
    int st;  // Service Time (Burst Time)
    int pr;  // Priority (1-10)
    int status; // 0: Not executed, 1: Completed
    int ft;  // Finish Time
} ready_list[10];

int n;

int dispatcher(int time) {
    int index = -1, high_pr = 0;

    for (int i = 0; i < n; i++) {
        if (ready_list[i].status != 1 && ready_list[i].at <= time) {
            if (ready_list[i].pr > high_pr) {
                high_pr = ready_list[i].pr;
                index = i;
            }
        }
    }
    return index;
}

int main() {
    printf("Enter number of processes: ");
    scanf("%d", &n);

    // Collect process details
    for (int i = 0; i < n; i++) {
        printf("Process %d\n***********\n", i + 1);
        printf("Enter Arrival Time: ");
        scanf("%d", &ready_list[i].at);
        printf("Enter Service Time: ");
        scanf("%d", &ready_list[i].st);
        printf("Priority (1-10): ");
        scanf("%d", &ready_list[i].pr);
        ready_list[i].status = 0; // Not executed yet
    }

    int cur_time = 0, i = 0;

    while (i < n) {
        int pid = dispatcher(cur_time);
        if (pid != -1) {
            ready_list[pid].ft = cur_time + ready_list[pid].st;
            ready_list[pid].status = 1; // Mark as completed
            cur_time += ready_list[pid].st;
            i++;
        } else {
            cur_time++; // Increment time if no process is ready
        }
    }

    // Print the results
    printf("Process\t Arrival Time\t Service Time\t Finish Time\t TT\t WT\n");
    printf("*******\t ************\t ************\t ***********\t ********\t ********\n");
    for (int i = 0; i < n; i++) {
        printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
               i + 1, ready_list[i].at, ready_list[i].st, ready_list[i].ft,
               ready_list[i].ft - ready_list[i].at, (ready_list[i].ft - ready_list[i].at) - ready_list[i].st);
    }

    return 0;
}
