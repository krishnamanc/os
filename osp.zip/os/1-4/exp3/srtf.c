#include <stdio.h>

struct process {
    int at;     // Arrival Time
    int st;     // Remaining Service Time (Burst Time)
    int status; // Status (0 = not completed, 1 = completed)
    int ft;     // Finish Time
} ready_list[10];

int n;

int dispatcher(int time) {
    int i, min_bt = 9999, index = -1;
    for (i = 0; i < n; i++) {
        if (ready_list[i].status == 0 && ready_list[i].at <= time && ready_list[i].st < min_bt) {
            min_bt = ready_list[i].st;
            index = i;
        }
    }
    return index;
}

int main() {
    int cur_time = 0, pid, rem_procs = 0;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        printf("Process %d\n***********\n", i + 1);
        printf("Enter Arrival Time: ");
        scanf("%d", &ready_list[i].at);
        printf("Enter Burst Time: ");
        scanf("%d", &ready_list[i].st);
        ready_list[i].status = 0; // Initially not completed
    }

    while (rem_procs < n) {
        pid = dispatcher(cur_time);
        if (pid != -1) {
            ready_list[pid].ft = cur_time + 1;
            cur_time++;
            ready_list[pid].st--;
            if (ready_list[pid].st == 0) {
                ready_list[pid].status = 1; // Mark as completed
                rem_procs++;
            }
        } else {
            cur_time++; // Increment time if no process is ready
        }
    }

    printf("\nProcess\t Arrival Time\t Burst Time\t Finish Time\n");
    printf("*******\t **********\t **********\t *********\n");
    for (int i = 0; i < n; i++) {
        printf("%d\t\t%d\t\t%d\t\t\t%d\n", i + 1, ready_list[i].at, ready_list[i].st + (ready_list[i].ft - cur_time + 1), ready_list[i].ft);
    }

    return 0;
}
