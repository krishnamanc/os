#include <stdio.h>

// Struct to store process details
struct process {
    int at;      // Arrival Time
    int st;      // Service Time (Burst Time)
    int cpu;     // CPU assigned
    int status;  // Process status (0: Not completed, 1: Completed)
    int ft;      // Finish Time
} ready_list[10];

int n;  // Number of processes

// Function to dispatch processes
int dispatcher(int time) {
    for (int i = 0; i < n; i++) {
        if (ready_list[i].status != 1 && ready_list[i].at <= time) {
            return i;  // Return the index of the process to be dispatched
        }
    }
    return -1;  // Return -1 if no process is ready
}

int main() {
    int h, cur_time[10];

    // Input number of processes and CPUs
    printf("Enter number of processes: ");
    scanf("%d", &n);
    printf("Enter number of CPUs: ");
    scanf("%d", &h);

    // Collect process details
    for (int i = 0; i < n; i++) {
        printf("Process %d\n", i + 1);
        printf("Enter Arrival Time: ");
        scanf("%d", &ready_list[i].at);
        printf("Enter Service Time: ");
        scanf("%d", &ready_list[i].st);
        ready_list[i].status = 0;  // Mark process as incomplete
    }

    // Initialize current time for each CPU
    for (int i = 0; i < h; i++) {
        cur_time[i] = 0;
    }

    int completed_processes = 0;
    while (completed_processes < n) {
        for (int j = 0; j < h && completed_processes < n; j++) {
            int pid = dispatcher(cur_time[j]);
            while (pid == -1) {
                cur_time[j]++;  // Increment time if no process is ready
                pid = dispatcher(cur_time[j]);
            }

            // If a process is found
            ready_list[pid].ft = cur_time[j] + ready_list[pid].st;  // Set 
            ready_list[pid].status = 1;                             // Mark 
            ready_list[pid].cpu = j + 1;                            // Assign 
            cur_time[j] += ready_list[pid].st;                      // Update 
            completed_processes++;                                  // 
        }
    }

    // Output results
    printf("Process\tArrival Time\tBurst Time\tFinish Time\tCPU\tTurnaround Time\tWaiting Time\n");
    for (int i = 0; i < n; i++) {
        int turnaround_time = ready_list[i].ft - ready_list[i].at;
        int waiting_time = turnaround_time - ready_list[i].st;
        printf("%d\t\t%d\t\t%d\t\t%d\t\t%d\t%d\t\t%d\n",
               i + 1, ready_list[i].at, ready_list[i].st, ready_list[i].ft, ready_list[i].cpu,
               turnaround_time, waiting_time);
    }

    return 0;
}
