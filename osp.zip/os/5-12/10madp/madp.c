#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_MEM_SIZE 1024 // Define maximum memory size for buddy system
#define MAX_PARTITIONS 10 // Define max partitions for dynamic partitioning

// Structure for a memory block in dynamic partitioning
struct Block {
    int size;
    int allocated;
    int processId;
};

struct Block partitions[MAX_PARTITIONS];
int partitionCount = 0;
int totalMemorySize;

// Functions for Dynamic Partitioning
void initPartitions(int size) {
    totalMemorySize = size;
    partitionCount = 1;
    partitions[0].size = size;
    partitions[0].allocated = 0;
    partitions[0].processId = -1;
}

int bestFit(int processId, int processSize) {
    int bestIdx = -1;
    for (int i = 0; i < partitionCount; i++) {
        if (!partitions[i].allocated && partitions[i].size >= processSize) {
            if (bestIdx == -1 || partitions[i].size < partitions[bestIdx].size) {
                bestIdx = i;
            }
        }
    }
    if (bestIdx != -1) {
        partitions[bestIdx].allocated = 1;
        partitions[bestIdx].processId = processId;
        printf("Allocated process %d to partition %d\n", processId, bestIdx);
    } else {
        printf("Failed to allocate process %d\n", processId);
    }
    return bestIdx;
}

void deallocateProcess(int processId) {
    for (int i = 0; i < partitionCount; i++) {
        if (partitions[i].allocated && partitions[i].processId == processId) {
            partitions[i].allocated = 0;
            partitions[i].processId = -1;
            printf("Deallocated process %d from partition %d\n", processId, i);
            return;
        }
    }
    printf("Process %d not found\n", processId);
}

void externalFragmentation() {
    int fragmented = 0;
    for (int i = 0; i < partitionCount; i++) {
        if (!partitions[i].allocated) {
            fragmented += partitions[i].size;
        }
    }
    printf("Total external fragmentation: %d\n", fragmented);
}

// Buddy System
int buddySystem[MAX_MEM_SIZE];

void initBuddySystem(int memorySize) {
    for (int i = 0; i < memorySize; i++) buddySystem[i] = -1;
}

int buddyAllocate(int size) {
    int order = ceil(log2(size));
    int blockSize = 1 << order;

    int i = 0;
    while (i + blockSize <= MAX_MEM_SIZE) {
        int isFree = 1;
        for (int j = i; j < i + blockSize; j++) {
            if (buddySystem[j] != -1) {
                isFree = 0;
                break;
            }
        }
        if (isFree) {
            for (int j = i; j < i + blockSize; j++) buddySystem[j] = i;
            printf("Allocated buddy block of size %d at position %d\n", blockSize, i);
            return i;
        }
        i += blockSize;
    }
    printf("Failed to allocate buddy block of size %d\n", size);
    return -1;
}

void buddyDeallocate(int pos) {
    if (pos < 0 || pos >= MAX_MEM_SIZE || buddySystem[pos] == -1) {
        printf("Invalid deallocation position\n");
        return;
    }
    int base = buddySystem[pos];
    int size = 1;
    while (base + size < MAX_MEM_SIZE && buddySystem[base + size] == base) {
        size++;
    }
    for (int i = base; i < base + size; i++) buddySystem[i] = -1;
    printf("Deallocated buddy block at position %d\n", pos);
}

int main() {
    int choice, processId, processSize;

    // Initialize Dynamic Partitioning
    printf("Enter total memory size for dynamic partitioning: ");
    scanf("%d", &totalMemorySize);
    initPartitions(totalMemorySize);

    // Initialize Buddy System
    initBuddySystem(MAX_MEM_SIZE);

    while (1) {
        printf("\n1. Allocate using Best-Fit (Dynamic Partitioning)\n");
        printf("2. Deallocate Process (Dynamic Partitioning)\n");
        printf("3. External Fragmentation (Dynamic Partitioning)\n");
        printf("4. Allocate Buddy System\n");
        printf("5. Deallocate Buddy System\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter process ID and size for allocation: ");
                scanf("%d %d", &processId, &processSize);
                bestFit(processId, processSize);
                break;
            case 2:
                printf("Enter process ID to deallocate: ");
                scanf("%d", &processId);
                deallocateProcess(processId);
                break;
            case 3:
                externalFragmentation();
                break;
            case 4:
                printf("Enter size for buddy system allocation: ");
                scanf("%d", &processSize);
                buddyAllocate(processSize);
                break;
            case 5:
                printf("Enter position to deallocate in buddy system: ");
                scanf("%d", &processId);
                buddyDeallocate(processId);
                break;
            case 6:
                exit(0);
        }
    }
    return 0;
}
