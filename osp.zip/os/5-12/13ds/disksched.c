#include <stdio.h>
#include <stdlib.h>

#define MAX 100

// Function to print the head movement and calculate seek time
int calculateSeekTime(int request[], int n, int head) {
    int seek_time = 0, distance, current_head = head;

    for (int i = 0; i < n; i++) {
        distance = abs(request[i] - current_head);
        printf("Disk head moves from %d to %d with seek %d\n", current_head, request[i], distance);
        seek_time += distance;
        current_head = request[i];
    }
    return seek_time;
}

// Helper function to sort array
void sortArray(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (arr[i] > arr[j]) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

// First-Come-First-Serve (FCFS) Algorithm
void FCFS(int request[], int n, int head) {
    printf("\nFCFS Disk Scheduling\n");
    int seek_time = calculateSeekTime(request, n, head);
    printf("Total seek time is %d\n", seek_time);
    printf("Average seek time is %.6f\n", (float)seek_time / n);
}

// Shortest Seek Time First (SSTF) Algorithm
void SSTF(int request[], int n, int head) {
    int completed[MAX] = {0}, seek_time = 0, current_head = head;

    printf("\nSSTF Disk Scheduling\n");
    for (int i = 0; i < n; i++) {
        int min_dist = MAX, index = -1;

        for (int j = 0; j < n; j++) {
            if (!completed[j] && abs(request[j] - current_head) < min_dist) {
                min_dist = abs(request[j] - current_head);
                index = j;
            }
        }
        if (index != -1) {
            printf("Disk head moves from %d to %d with seek %d\n", current_head, request[index], min_dist);
            seek_time += min_dist;
            current_head = request[index];
            completed[index] = 1;
        }
    }
    printf("Total seek time is %d\n", seek_time);
    printf("Average seek time is %.6f\n", (float)seek_time / n);
}

// SCAN Algorithm
void SCAN(int request[], int n, int head, int max_range) {
    int sorted[MAX], seek_time = 0, i;

    for (i = 0; i < n; i++) sorted[i] = request[i];
    sorted[n++] = 0;
    sorted[n++] = max_range - 1;

    sortArray(sorted, n);

    printf("\nSCAN Disk Scheduling\n");
    for (i = 0; i < n; i++) {
        if (sorted[i] >= head) break;
    }

    seek_time = calculateSeekTime(sorted + i, n - i, head) + calculateSeekTime(sorted, i, sorted[n - 1]);
    printf("Total seek time is %d\n", seek_time);
    printf("Average seek time is %.6f\n", (float)seek_time / (n - 2));
}

// C-LOOK Algorithm
void C_LOOK(int request[], int n, int head) {
    int sorted[MAX], seek_time = 0, i;

    for (i = 0; i < n; i++) sorted[i] = request[i];
    sortArray(sorted, n);

    printf("\nC-LOOK Disk Scheduling\n");
    for (i = 0; i < n; i++) {
        if (sorted[i] >= head) break;
    }

    seek_time = calculateSeekTime(sorted + i, n - i, head) + calculateSeekTime(sorted, i, sorted[n - 1]);
    printf("Total seek time is %d\n", seek_time);
    printf("Average seek time is %.6f\n", (float)seek_time / n);
}

int main() {
    int n, head, max_range;
    int request[MAX];

    printf("Enter the max range of disk: ");
    scanf("%d", &max_range);

    printf("Enter the size of queue request: ");
    scanf("%d", &n);

    printf("Enter the queue of disk positions to be read: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &request[i]);
    }

    printf("Enter the initial head position: ");
    scanf("%d", &head);

    FCFS(request, n, head);
    SSTF(request, n, head);
    SCAN(request, n, head, max_range);
    C_LOOK(request, n, head);

    return 0;
}
