#include <stdio.h>
#include <limits.h>

struct RAM {
    int pno;
} frame[10];

int n, q_ptr = 0;

// Function Prototypes
void init();
void display();
int isinRAM(int p_no);
int findLRUIndex(int page_req[], int curr_index);

int main() {
    int pf = 0, np;

    // Input for number of frames and page requests
    printf("Enter the number of frames in memory: ");
    scanf("%d", &n);
    printf("Enter the number of page requests: ");
    scanf("%d", &np);

    int page_req[np];
    printf("\nEnter the Page number requested one by one: ");
    for (int i = 0; i < np; i++) {
        scanf("%d", &page_req[i]);
    }

    // Initialize frames and display the initial state
    init();
    display();

    // Process each page request
    for (int i = 0; i < np; i++) {
        if (isinRAM(page_req[i]) != -1) {
            printf("\nPage Exists...");
        } else {
            pf++;
            printf("\nPage Fault %d", pf);

            if (q_ptr < n) {
                // Place the page in an empty frame
                frame[q_ptr++].pno = page_req[i];
            } else {
                // Replace page using LRU page replacement logic
                int lru_idx = findLRUIndex(page_req, i);
                frame[lru_idx].pno = page_req[i];
            }
        }
        display();
    }

    return 0;
}

// Initialize frames to -1 (empty)
void init() {
    for (int i = 0; i < n; i++) {
        frame[i].pno = -1;
    }
}

// Display the current state of the frames
void display() {
    printf("\nFrame (RAM):");
    for (int i = 0; i < n; i++) {
        printf("\n%d", frame[i].pno);
    }
    printf("\n");
}

// Check if the page is already in RAM
int isinRAM(int p_no) {
    for (int i = 0; i < n; i++) {
        if (frame[i].pno == p_no) {
            return i;  // Page found
        }
    }
    return -1;  // Page not found
}

// Find the least recently used page to replace
int findLRUIndex(int page_req[], int curr_index) {
    int prev_occ[n], i, j;

    // Initialize previous occurrence array with INT_MAX
    for (i = 0; i < n; i++) {
        prev_occ[i] = INT_MAX;
    }

    // Find the last occurrence of each page in the frames
    for (i = 0; i < n; i++) {
        for (j = curr_index - 1; j >= 0; j--) {
            if (page_req[j] == frame[i].pno) {
                prev_occ[i] = j;
                break;
            }
        }
    }

    // Find the frame with the smallest (oldest) last occurrence
    int min_occ = prev_occ[0], lru_idx = 0;
    for (i = 1; i < n; i++) {
        if (prev_occ[i] < min_occ) {
            min_occ = prev_occ[i];
            lru_idx = i;
        }
    }

    return lru_idx;
}
