#include <stdio.h>

#define MAX 100

int main() {
    int memorySize, pageSize, numPages, numProcesses;
    int pageTable[MAX][MAX]; // Stores the page table for each process
    int pagesPerProcess[MAX]; // Stores the number of pages each process requires
    int i, j, processNo, pageNumber, offset;
    int logicalAddress, physicalAddress;

    // Input memory and page details
    printf("Enter the memory size: ");
    scanf("%d", &memorySize);

    printf("Enter the page size: ");
    scanf("%d", &pageSize);

    numPages = memorySize / pageSize;
    printf("The number of pages available in memory are %d\n", numPages);

    printf("Enter number of processes: ");
    scanf("%d", &numProcesses);

    // Input the page table for each process
    for (i = 0; i < numProcesses; i++) {
        printf("Enter number of pages required for p[%d]: ", i + 1);
        scanf("%d", &pagesPerProcess[i]);

        if (pagesPerProcess[i] > numPages) {
            printf("Memory is full!\n");
            return 0;
        }

        printf("Enter page table for p[%d]: ", i + 1);
        for (j = 0; j < pagesPerProcess[i]; j++) {
            scanf("%d", &pageTable[i][j]);
        }
    }

    // Input logical address details
    printf("Enter Logical Address to find Physical Address\n");
    printf("Enter process no.: ");
    scanf("%d", &processNo);

    printf("Enter page number: ");
    scanf("%d", &pageNumber);

    printf("Enter offset: ");
    scanf("%d", &offset);

    // Validate process number and page number
    if (processNo < 1 || processNo > numProcesses) {
        printf("Invalid process number!\n");
        return 0;
    }

    if (pageNumber >= pagesPerProcess[processNo - 1]) {
        printf("Invalid page number!\n");
        return 0;
    }

    // Calculate the physical address
    physicalAddress = pageTable[processNo - 1][pageNumber] * pageSize + offset;

    // Output the physical address
    printf("The Physical Address is -- %d\n", physicalAddress);

    return 0;
}
