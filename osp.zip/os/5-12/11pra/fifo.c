#include<stdio.h>

struct RAM {
    int pno;
} frame[10];

int N, q_ptr = 0;

// Function Prototypes
void init();
void display();
int isitinRAM(int p_no);

int main() {
    int p_no, pf = 0;

    printf("Enter the number of Frames in memory: ");
    scanf("%d", &N);

    init();
    display();

    while (1) {
        printf("\nRequest Page.No (-1 to exit): ");
        scanf("%d", &p_no);

        if (p_no == -1) break;

        if (isitinRAM(p_no) != -1) {
            printf("\nPage Exists");
        } else {
            pf++;
            printf("\nPage Fault %d", pf);
            frame[q_ptr].pno = p_no;
            q_ptr = (q_ptr + 1) % N;  // Circular queue logic
        }

        display();
    }
    return 0;
}

// Check if the page is already in RAM
int isitinRAM(int p_no) {
    for (int i = 0; i < N; i++) {
        if (frame[i].pno == p_no)
            return i;
    }
    return -1;  // Page not found
}

// Initialize frames with -1 (indicating empty frames)
void init() {
    for (int i = 0; i < N; i++)
        frame[i].pno = -1;
}

// Display the current frames
void display() {
    printf("\nFrame (RAM):");
    for (int i = 0; i < N; i++)
        printf("\n%d", frame[i].pno);
}
