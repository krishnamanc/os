#include<stdio.h>
struct process{
int max[100],alloc[100],need[100];
int status;
}p[100];
int nr,np,k;
int avai[100]={0};
int work[100]={0};
int req[100]={0};
int safeSequence[100]={-1};
int si=0;
void display(){
printf("Process\tMaximum\tAllocated\tNeed\n");
int i,j;
for(i=0;i<np;i++){
printf("P%d\t",i+1);
for(j=0;j<nr;j++){printf("%d ",p[i].max[j]);
}
printf("\t");
for(j=0;j<nr;j++){
printf("%d ",p[i].alloc[j]);
}
printf("\t\t");
for(j=0;j<nr;j++){
printf("%d ",p[i].need[j]);
}
printf("\n");
}
printf("\nAvailable:\n");
for(j=0;j<nr;j++){
printf("%d\t",avai[j]);
}
printf("\n");
}
int resoureRequest(){
int j;
for(j=0;j<nr;j++){
if (req[j]>p[k].need[j]){
return 0;
}
}
for(j=0;j<nr;j++){
if (req[j]>avai[j]){
return 0;
}
}
for(j=0;j<nr;j++){
avai[j]-=req[j];
work[j]-=req[j];
p[k].alloc[j]+=req[j];
p[k].need[j]-=req[j];}
return 1;
}
int safety(){
int i,j,flag,flag2,cp=0;
while(cp<np){
flag=0;
for (i=0;i<np;i++){
flag2=1;
if(p[i].status==0){
for(j=0;j<nr;j++){
if (p[i].need[j]>work[j]){
flag2=0;
break;
}
}
if(flag2==1){
cp++;
safeSequence[si]=i+1;
si++;
p[i].status=1;
flag=1;
for(j=0;j<nr;j++){
printf("%d ",p[i].need[j]);
}
for(j=0;j<nr;j++){
work[j]+=p[i].alloc[j];
printf("%d ",work[j]);
}
printf("\n");
}
}
}
if (flag==0)return 0;
}
return 1;
}
int main(){
printf("Enter number of processes:");
scanf("%d",&np);
printf("Enter number of resources:");
scanf("%d",&nr);
int i,j,op;
for(i=0;i<np;i++){
printf("For process P%d\n",i+1);
for(j=0;j<nr;j++){
printf("Enter maximum demand for resource %d:",j+1);
scanf("%d",&p[i].max[j]);
printf("Enter allocated instances for resource %d:",j+1);
scanf("%d",&p[i].alloc[j]);
p[i].need[j]=p[i].max[j]-p[i].alloc[j];
p[i].status=0;
}
}
for(j=0;j<nr;j++){
printf("Enter available instances for resource %d:",j+1);
scanf("%d",&avai[j]);
work[j]=avai[j];
}
printf("Are additinal resources are requested?(1.Yes/2.No)");
scanf("%d",&op);
if(op==1){
printf("Process requesting:");
scanf("%d",&k);
for(j=0;j<nr;j++){
printf("Enter additional demand for resource %d:",j+1);
scanf("%d",&req[j]);
}if (resoureRequest()==1)
printf("Resources can be granted.\n");
else
printf("Resources can not be granted.\n");
}
display();
if(safety()==1){
printf("Processes are in safe state.\n");
printf("Safe sequence:\n");
for(i=0;i<np;i++)
printf("%d ",safeSequence[i]);
}
else
printf("Processes are in unsafe state.\n");
return 0;
}
