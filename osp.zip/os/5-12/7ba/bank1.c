#include <stdio.h>
int need[5][5], max[5][5], allocation[5][5],avl[5];
int allocated_resources[5] = {0,0,0,0,0};
int maxres[5], completed[5], safe=0;
int count = 0, i, j, exec, r, p;
int main()
{
printf("\nEnter the number of processes: ");
scanf("%d",&p);
for(i=0;i<p;i++)
{
completed[i]=0;
count++;
}
printf("\nEnter the number of resources: ");
scanf("%d",&r);
printf("\nEnter the available (AVL) number of instances of resource");
for(i=0;i<r;i++)
{
printf("Resource:%d: ",i);
scanf("%d",&avl[i]);}
printf("\nEnter maximum resource( Max) demand of each process:\n");
for(i=0;i<p;i++)
{
printf("Process %d :\n",i);
for(j=0;j<r;j++)
{
scanf("%d",&max[i][j]);
}
}
printf("\nEnter already allocated resource table (Allocation) ):\n");
for(i=0;i<p;i++)
{
printf("Process %d:\n",i);
for(j=0;j<r;j++)
{
scanf("%d",&allocation[i][j]);
}
}
int x=0;
for(i=0;i<r;i++)
{
for(j=0;j<p;j++)
{
allocated_resources[i]+=allocation[j][i];
}
}
for(i=0;i<r;i++)
{
maxres[i]=avl[i]+allocated_resources[i];
}
printf("\nMaximum resources:");
for(i=0;i<r;i++){
printf("\t%d",maxres[i]);
}
printf("\n");
for(i=0;i<p;i++)
for(j=0;j<r;j++)
need[i][j]=max[i][j]-allocation[i][j];
//Main procedure goes below to check for unsafe state.
while(count!=0)
{
safe=0;
for(i=0;i<p;i++)
{
if(!completed[i])
{
exec=1;
for(j=0;j<r;j++)
{
if(need[i][j] > avl[j]){
exec=0;
break;
}
}
if(exec) // Process i can be completed with available resources
{
printf("P%d\t",i);
completed[i]=1; // Process i executed with available resources
count--;
safe=1;
for(j=0;j<r;j++) {
avl[j]+=allocation[i][j];
}break;
}
}
}
if(!safe)
{
printf("\nThe system is in unsafe state.\n");
break;
}
}
if(safe)
printf("\nThe system is in safe state");
}
