package com.calc;

public class primee
{
public boolean findPrime(int a) {
        if (a <= 1) {
            return false; // Numbers less than or equal to 1 are not prime
        }
        if (a == 2) {
            return true; // 2 is the only even prime number
        }
        if (a % 2 == 0) {
            return false; // Exclude all other even numbers
        }

        for (int i = 3; i <= Math.sqrt(a); i += 2) { // Use `<=` to include the square root
            if (a % i == 0) {
                return false; // If `a` is divisible by `i`, it is not prime
            }
        }
        return true; // If no divisors found, `a` is prime
    }
}
