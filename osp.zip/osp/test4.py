from smtplib import SMTP
import getpass

server = SMTP('smtp.gmail.com', 587)
server.starttls()
server.ehlo()

email_address = "126003236@sastra.ac.in"
password = getpass.getpass("Enter your password: ")

server.login(email_address, password)
sent_from = email_address
to = "126003168@sastra.ac.in"  
subject = "Dengey ra"
body = "Hello everyone! Welcome to the Python class."


emailtext=subject+" "+body
server.sendmail(sent_from, to, emailtext)
print("Email sent!")

server.quit()